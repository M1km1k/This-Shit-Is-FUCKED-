﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertionConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Constants for conversion

            const double centimetersPerInch = 2.54;
            const double inchesPerFoot = 12;
            const double feetPerYard = 3;

            // Input length in centimeters

            Console.Write("Enter the length in centimeters: ");
            double lengthInCentimeters = Convert.ToDouble(Console.ReadLine());

            // Convert length to inches

            double lengthInInches = lengthInCentimeters / centimetersPerInch;

            // Convert inches to yards, feet, and remaining inches

            double totalInches = Math.Round(lengthInInches); // Rounding to the nearest inch
            double yards = (int)(totalInches / (inchesPerFoot * feetPerYard));
            double remainingFeet = (int)((totalInches % (inchesPerFoot * feetPerYard)) / inchesPerFoot);
            double remainingInches = totalInches % inchesPerFoot;

            // Output the result
            Console.WriteLine($"Length: {yards} yards, {remainingFeet} feet, {remainingInches} inches");



        }
    }
}
