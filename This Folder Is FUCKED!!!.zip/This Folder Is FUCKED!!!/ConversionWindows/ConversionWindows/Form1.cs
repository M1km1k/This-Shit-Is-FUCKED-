﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConversionWindows
{
    public partial class ConFrm : Form
    {
        public ConFrm()
        {
            InitializeComponent();
        }

        private void ConvertBtn_Click(object sender, EventArgs e)
        {

            txtOutput.Text = Convertion(double.Parse(txtInput.Text)).ToString();  




        }

        private double Convertion(double lengthinCentimeters)
        {

            // Constants for conversion

            const double centimetersPerInch = 2.54;
            const double inchesPerFoot = 12;
            const double feetPerYard = 3;

            // Input length in centimeters

            Console.Write("Enter the length in centimeters: ");
            double lengthInCentimeters = Convert.ToDouble(Console.ReadLine());

            // Convert length to inches

            double lengthInInches = lengthInCentimeters / centimetersPerInch;

            // Convert inches to yards, feet, and remaining inches

            double totalInches = Math.Round(lengthInInches); // Rounding to the nearest inch
            double yards = (int)(totalInches / (inchesPerFoot * feetPerYard));
            double remainingFeet = (int)((totalInches % (inchesPerFoot * feetPerYard)) / inchesPerFoot);
            double remainingInches = totalInches % inchesPerFoot;

            // Output the result
            return Console.WriteLine($"Length: {yards} yards, {remainingFeet} feet, {remainingInches} inches");


        }

    }
}
