﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeConsole
{
    internal class Program
    {

        static void Main(string[] args)
        {

            // Author: I'm a good guy I don't use Chat GPT

            // Declaration of variables

            int bagsOrdered;
            double bagPrice = 5.50;
            double largeBoxPrice = 3.00;
            double mediumBoxPrice = 2.50;
            double smallBoxPrice = 2.00;

            int largeBoxCapacity = 20;
            int mediumBoxCapacity = 10;
            int smallBoxCapacity = 5;

            // Input 

                Console.Write("Number of bags ordered: ");
                bagsOrdered = int.Parse(Console.ReadLine());

            // Prpcess

            int largeBoxesUsed = bagsOrdered / largeBoxCapacity;
            int mediumBoxesUsed = (bagsOrdered % largeBoxCapacity) / mediumBoxCapacity;
            int smallBoxesUsed = ((bagsOrdered % largeBoxCapacity) % mediumBoxCapacity) / smallBoxCapacity;

            if (((bagsOrdered % largeBoxCapacity) % mediumBoxCapacity) % smallBoxCapacity != 0)
                smallBoxesUsed += 1;

            double totalCost = (largeBoxesUsed * largeBoxPrice) + (mediumBoxesUsed * mediumBoxPrice) + (smallBoxesUsed * smallBoxPrice) + (bagsOrdered * bagPrice);

            // Output

                Console.WriteLine("Boxes Used:" + bagsOrdered );
                Console.WriteLine("Large - " + largeBoxesUsed);
                Console.WriteLine("Medium - " + mediumBoxesUsed);
                Console.WriteLine("Small - " + smallBoxesUsed);
                Console.WriteLine("Your total cost is: $" + totalCost);

        }
    }
}
